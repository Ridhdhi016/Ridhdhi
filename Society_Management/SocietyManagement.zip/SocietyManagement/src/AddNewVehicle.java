import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AddNewVehicle
 */
@WebServlet("/AddNewVehicle")
public class AddNewVehicle extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String vehicle_type = request.getParameter("user_vehicle_type");
		String vehicle_reg_no = request.getParameter("user_vehicle_reg_number");
		String vehicle_color = request.getParameter("user_vehicle_color");

		try {
			
			HttpSession session=request.getSession(false);  
	        String email=(String)session.getAttribute("login_email");  
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/society_management","root","root");
	
			PreparedStatement stmt = con.prepareStatement("INSERT INTO vehicle_add(type, registration_number, color, email) VALUES(?,?,?,?)");
	
	
			stmt.setString(1, vehicle_type);
			stmt.setString(2, vehicle_reg_no);
			stmt.setString(3, vehicle_color);
			stmt.setString(4, email);
			
			int i = stmt.executeUpdate();
			if(i>0){
				out.println("<center><h2>Vehicle added successfully...</h2><center><br>");
				out.println("<center><a href='vehicle_management_main.jsp'>Click here to use more vehicle management services...</a><center>");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}

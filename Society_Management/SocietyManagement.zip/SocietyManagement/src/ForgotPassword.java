

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ForgotPassword
 */
@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("user_email");
		
		try {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/society_management","root","root");
	
			Statement stmt = con.createStatement();
			String sql ="SELECT email FROM register";

			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
			String reg_email = rs.getString("email");
			if(email.equals(reg_email)){
				
				Random rnum = new Random();
				int min = 100000;
				int max = 999999;
				int OTP = rnum.nextInt(max - min) + min;
				String otpsent = String.valueOf(OTP);
				String subject = "OTP for Society Management";
				SendEmail.sendEmail(otpsent, subject, email);
				HttpSession session=request.getSession();  
		        session.setAttribute("otp",otpsent);
		        session.setAttribute("e", email);
				
				out.println("<center><h3>OTP is sent to your email id...</h3></center><br>");
				out.println("<center><a href='otp.jsp'>Verify OTP</a><center>");
				}
			
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}

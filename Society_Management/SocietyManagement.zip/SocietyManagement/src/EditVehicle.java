import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EditVehicle
 */
@WebServlet("/EditVehicle")
public class EditVehicle extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String vehicle_type = request.getParameter("edit_vehicle_type");
		String vehicle_reg_no = request.getParameter("edit_vehicle_reg_number");
		String vehicle_color = request.getParameter("edit_vehicle_color");
		
		try {
			
			//String registration_no = request.getParameter("reg_no");

			HttpSession session=request.getSession(false); 
			String registration_no=(String)session.getAttribute("r");
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/society_management","root","root");
	
			PreparedStatement stmt = con.prepareStatement("UPDATE vehicle_add SET type=?, registration_number=?, color=? WHERE registration_number='"+registration_no+"'");
	
	
			stmt.setString(1, vehicle_type);
			stmt.setString(2, vehicle_reg_no);
			stmt.setString(3, vehicle_color);
			
			int i = stmt.executeUpdate();
			if(i>0){
				out.println("<center><h2>Vehicle edited successfully...</h2><center><br>");
				out.println("<center><a href='edit_vehicle.jsp'>Click here to edit more vehicles...</a><center>");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class NewPassUpdate
 */
@WebServlet("/NewPassUpdate")
public class NewPassUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
    

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String new_password = request.getParameter("user_password");
		String new_cpassword = request.getParameter("user_confirmpassword");
		
		HttpSession session=request.getSession();  
        String eml = (String)session.getAttribute("e");
        
        try {
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/society_management","root","root");
	
			PreparedStatement stmt = con.prepareStatement("UPDATE register SET password=?, confirm_password=? WHERE email='"+eml+"'");
	
	
			stmt.setString(1, new_password);
			stmt.setString(2, new_password);
			
			int i = stmt.executeUpdate();
			if(i>0 && new_password.equals(new_cpassword)){
				out.println("<center><h2>Password Updated successfully...</h2><center><br>");
				out.println("<center><a href='loginform.jsp'>Click here to login...</a><center>");
			}
			else {
				out.println("<center><h2>Password & Confirm Password doesn't match...</h2></center>");
				out.println("<center><a href='newpassword.jsp'>Try Again...</a><center>");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}

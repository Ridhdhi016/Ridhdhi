

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class VerifyOTP
 */
@WebServlet("/VerifyOTP")
public class VerifyOTP extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String otp_entered = request.getParameter("entered_otp");
		
		HttpSession session=request.getSession();  
        String otp_sent = (String)session.getAttribute("otp");
        
        response.setContentType("text/html");
		PrintWriter out = response.getWriter();
        if(otp_entered.equals(otp_sent)) {
        	out.println("OTP verified successfully..");
        	response.sendRedirect("newpassword.jsp");
        }
        else {
        	out.println("<center><h3>OTP not verified....</h3></center><br>");
        	out.println("<center><a href='forgotpassform.jsp'>Click here to get new OTP...</a><center>");
        	
        }
	}

}
